#
# Behavior Tree framework for A1 Behavior trees assignment.
# CS131 - Artificial Intelligence
#
# Version 1.0.2 - copyright (c) 2023 Santini Fabrizio. All rights reserved.
#

BOXES = [(20, 6), (30, 5), (60, 8), (90, 7), (50, 6), (70, 9),
         (30, 4), (30, 5), (70, 4), (20, 9), (20, 2), (60, 1)]
